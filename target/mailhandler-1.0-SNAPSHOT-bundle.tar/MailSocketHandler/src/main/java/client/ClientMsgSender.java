package client;

import messages.EmailReqMsg;

public class ClientMsgSender
{
	private SocketClient socketClient;

	public ClientMsgSender( SocketClient socketClient)
	{
	}

	public void sendMsg( EmailReqMsg emailReqMsg ){
	}
}
